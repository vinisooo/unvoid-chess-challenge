type TPiece = 'dev' | 'designer' | 'po'

export type { TPiece } 